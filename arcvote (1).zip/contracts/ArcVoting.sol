// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title ArcVoting — On-chain voting for Arc Network
/// @dev RPC: https://rpc.testnet.arc.network | ChainID: 5042002
contract ArcVoting {
    struct Proposal {
        string  text;
        address proposer;
        uint256 yesVotes;
        uint256 noVotes;
        uint256 abstainVotes;
        uint256 createdAt;
    }

    Proposal[] public proposals;
    mapping(address => mapping(uint256 => bool)) public hasVoted;

    event ProposalAdded(uint256 indexed id, string text, address indexed proposer);
    event Voted(address indexed voter, uint256 indexed proposalId, uint8 option);

    /// @param option 0=yes | 1=no | 2=abstain
    function vote(uint256 proposalId, uint8 option) external {
        require(proposalId < proposals.length, "Invalid proposal");
        require(!hasVoted[msg.sender][proposalId], "Already voted");
        require(option <= 2, "Invalid option");
        hasVoted[msg.sender][proposalId] = true;
        if (option == 0)      proposals[proposalId].yesVotes++;
        else if (option == 1) proposals[proposalId].noVotes++;
        else                  proposals[proposalId].abstainVotes++;
        emit Voted(msg.sender, proposalId, option);
    }

    function addProposal(string calldata text) external returns (uint256 id) {
        id = proposals.length;
        proposals.push(Proposal(text, msg.sender, 0, 0, 0, block.timestamp));
        emit ProposalAdded(id, text, msg.sender);
    }

    function getProposal(uint256 id) external view returns (Proposal memory) {
        require(id < proposals.length, "Invalid proposal");
        return proposals[id];
    }

    function proposalCount() external view returns (uint256) {
        return proposals.length;
    }
}
