#!/bin/bash
# ─────────────────────────────────────────────────────────
#  Arc Testnet — Foundry Deploy Script
#  Docs: https://docs.arc.io/arc/tutorials/deploy-on-arc
# ─────────────────────────────────────────────────────────
#  1. Install Foundry:  curl -L https://foundry.paradigm.xyz | bash && foundryup
#  2. Get USDC:         https://faucet.circle.com  (select Arc Testnet)
#  3. Set private key:  export PRIVATE_KEY=0xYOUR_KEY_HERE
#  4. Run:              bash deploy.sh
# ─────────────────────────────────────────────────────────

ARC_RPC="https://rpc.testnet.arc.network"
CHAIN_ID=5042002

echo ">> Deploying ArcGM..."
GM_OUT=$(forge create contracts/ArcGM.sol:ArcGM \
  --rpc-url $ARC_RPC --chain-id $CHAIN_ID \
  --private-key $PRIVATE_KEY --broadcast 2>&1)
GM_ADDR=$(echo "$GM_OUT" | grep "Deployed to:" | awk '{print $3}')
echo "   ArcGM -> $GM_ADDR"

echo ">> Deploying ArcVoting..."
VOTE_OUT=$(forge create contracts/ArcVoting.sol:ArcVoting \
  --rpc-url $ARC_RPC --chain-id $CHAIN_ID \
  --private-key $PRIVATE_KEY --broadcast 2>&1)
VOTE_ADDR=$(echo "$VOTE_OUT" | grep "Deployed to:" | awk '{print $3}')
echo "   ArcVoting -> $VOTE_ADDR"

echo ""
echo "═══════════════════════════════════════════════════"
echo "Paste into arc-dapp.html (search: VOTING_CONTRACT):"
echo "   let VOTING_CONTRACT = '${VOTE_ADDR}';"
echo "   let GM_CONTRACT     = '${GM_ADDR}';"
echo ""
echo "ArcScan links:"
echo "   https://testnet.arcscan.app/address/${VOTE_ADDR}"
echo "   https://testnet.arcscan.app/address/${GM_ADDR}"
echo "═══════════════════════════════════════════════════"
