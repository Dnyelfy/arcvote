// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title ArcGM — On-chain GM/GN messages for Arc Network
/// @dev Every call emits a permanent event visible on ArcScan
contract ArcGM {
    event Message(address indexed sender, string msg, uint256 timestamp);

    function gm() external { emit Message(msg.sender, "GM", block.timestamp); }
    function gn() external { emit Message(msg.sender, "GN", block.timestamp); }
}
